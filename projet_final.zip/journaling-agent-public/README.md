# 📓 Journaling AI Agent

Un Agent IA personnel sur Telegram pour le journaling quotidien, développé dans le cadre du projet final de la formation **CS50 Introduction to Python Programming**, s'inscrivant plus largement dans une démarche de préparation pour un Travail de Bachelor (TB).

Un Agent IA auquel on peut parler par texte ou audio via Telegram, qui utilise Claude (Haiku) avec des outils MCP pour enregistrer, modifier, résumer et rechercher des entrées de journal.

## Fonctionnement

1. Un message texte ou vocal est envoyé au bot Telegram
2. Les messages vocaux sont transcrits via OpenAI Whisper (`gpt-4o-mini-transcribe`)
3. Le message est transmis à un `MCPClient` qui pilote une boucle d'appels d'outils Claude
4. L'agent sélectionne et appelle les outils MCP appropriés (log, résumé, recherche…)
5. Le résultat est renvoyé en réponse Telegram

```
Telegram ──► main.py ──► MCPClient ──► Agent IA (Claude Haiku)
                                               │
                                   ┌───────────┴───────────┐
                                   ▼                       ▼
                               Outils MCP            SQLite / .txt
                              (server.py)            (store/)
```

## Architecture

Deux processus communiquent via **transport MCP stdio** :

| Fichier | Rôle |
|---|---|
| `main.py` | Bot Telegram — route les messages texte/vocal vers `MCPClient` |
| `client/mcp_client.py` | Connexion au serveur MCP, pilote la boucle d'outils de l'agent |
| `server/server.py` | Point d'entrée du serveur MCP — enregistre tous les outils |
| `server/mcp_server.py` | Singleton FastMCP partagé par tous les outils |
| `server/prompts.py` | Prompts système : `get_agent_system_prompt()`, `summarize_day()` |
| `config.py` | Chemins + `get_db()` — initialisation du schéma SQLite |
| `utils/transcribe.py` | Transcription vocale via OpenAI Whisper |
| `tools/` | Un fichier par outil MCP, chacun décoré avec `@mcp.tool()` |

## Outils MCP

| Outil | Description |
|---|---|
| `log_entry` | Insère un nouveau log dans SQLite. Un log par date. Fallback `.txt` si erreur DB. |
| `append_to_log` | Ajoute un bloc `[EDIT timestamp]` à un log existant. |
| `get_logs` | Récupère le contenu brut des logs pour une liste de dates. |
| `create_summary` | Écrit des fichiers `.md` de résumé, insère en DB et git push. |
| `list_logs` | Liste toutes les dates ayant un log. |
| `list_logs_to_summarize` | Liste les dates avec un log mais sans résumé. |
| `list_summaries` | Liste toutes les dates ayant un résumé. |
| `search_entries` | Recherche sémantique (stub — pas encore implémenté). |

## Stockage

- **SQLite** (`store/journaling_agent.db`) — stockage principal
  - `logs(id, date, content, phase, char_count, summarized, created_at, modified_at)`
  - `summaries(id, date, content, created_at)`
- **Fallback `.txt`** (`store/logs/YYYY-MM-DD.txt`) — utilisé si la DB est indisponible
- **Repo git des résumés** (`store/summaries/`) — son propre `.git`, auto-pushé après chaque résumé

## Installation

### Prérequis

- Python 3.13+
- [`uv`](https://github.com/astral-sh/uv) — gestionnaire de paquets
- Un token de bot Telegram ([BotFather](https://t.me/BotFather))
- Clé API Anthropic
- Clé API OpenAI (pour la transcription vocale)

### Cloner et installer

```bash
git clone https://github.com/K-sel/mcp-journaling-bot
cd mcp-journaling-bot
uv sync
```

### Variables d'environnement

Créer un fichier `.env` à la racine :

```env
TELEGRAM_BOT_TOKEN=ton_token_telegram
TELEGRAM_USER_ID=ton_user_id_telegram
ANTHROPIC_API_KEY=ta_cle_anthropic
OPENAI_API_KEY=ta_cle_openai
```

> Un seul identifiant Telegram est autorisé — l'agent est strictement personnel.

### Lancer

```bash
# Démarrer le bot Telegram (se connecte automatiquement au serveur MCP)
uv run python main.py

# Démarrer le serveur MCP en standalone (pour les tests)
uv run python server/server.py
```

Ou via Make :

```bash
make run
```

## Phases du TB

Les entrées sont taguées avec une enum `Phase` qui suit l'avancement du TB :

| Phase | Description |
|---|---|
| `pre-etude` | Pré-étude / exploration |
| `architecture` | Conception & architecture |
| `developpement` | Développement |
| `documentation` | Rédaction de la documentation |
| `oral` | Préparation de la soutenance orale |

## Notes

- Les résumés ne sont **jamais créés automatiquement** — ils doivent être explicitement demandés
- Les dates ambiguës sont toujours confirmées avant toute écriture
- `store/summaries/` a son propre `.git` — non inclus dans les commits du repo principal
- `.env` et `store/vectors/` sont gitignorés