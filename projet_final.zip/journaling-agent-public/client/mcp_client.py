import asyncio, os, sys, logging
from pathlib import Path
from typing import Optional
from contextlib import AsyncExitStack

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from anthropic import Anthropic

from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, ContextTypes, filters

from utils.prompts import get_agent_system_prompt

logging.basicConfig(level=logging.INFO)

TELEGRAM_BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
ALLOWED_USER_ID = int(os.environ["TELEGRAM_USER_ID"])


class MCPClient:
    def __init__(self):
        self.session: Optional[ClientSession] = None
        self.exit_stack = AsyncExitStack()
        self.anthropic = Anthropic()
        self.messages = []

    async def connect_to_server(self, server_script_path: str):
        command = sys.executable

        server_params = StdioServerParameters(
            command=command,
            args=[server_script_path],
            env={
                **os.environ
            },
            cwd=str(Path(server_script_path).parent.parent),
        )

        stdio_transport = await self.exit_stack.enter_async_context(
            stdio_client(server_params)
        )

        self.stdio, self.write = stdio_transport
        self.session = await self.exit_stack.enter_async_context(
            ClientSession(self.stdio, self.write)
        )
        await self.session.initialize()

        response = await self.session.list_tools()

        print("Connected with : ", [t.name for t in response.tools])

    async def process_query(self, query: str) -> str:
        response = await self.session.list_tools()
        
        available_tools = [
            {
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.inputSchema,
            }
            for tool in response.tools
        ]

        MAX_HISTORY = 20

        self.messages.append({"role": "user", "content": query})
        if len(self.messages) > MAX_HISTORY:
            self.messages = self.messages[-MAX_HISTORY:]

        response = self.anthropic.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=4096,
            system=get_agent_system_prompt(),
            tools=available_tools,
            messages=self.messages,
        )
        
        

        while response.stop_reason == "tool_use":
            tool_blocks = [b for b in response.content if b.type == "tool_use"]

            self.messages.append({"role": "assistant", "content": [b.model_dump() for b in response.content]})

            tool_results = []
            for tb in tool_blocks:
                result = await self.session.call_tool(tb.name, tb.input)
                text = "".join(b.text for b in result.content if hasattr(b, "text"))
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": tb.id,
                    "content": text,
                })

            self.messages.append({"role": "user", "content": tool_results})

            response = self.anthropic.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=4096,
                system=get_agent_system_prompt(),
                tools=available_tools,
                messages=self.messages,
            )

        final_text = next(b.text for b in response.content if b.type == "text")
        self.messages.append({"role": "assistant", "content": final_text})

        return final_text

    async def cleanup(self):
        await self.exit_stack.aclose()
