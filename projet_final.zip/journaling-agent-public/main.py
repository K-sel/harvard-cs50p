from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, CommandHandler, ContextTypes, filters
import os, logging, asyncio
from utils.transcribe import transcribe
from client.mcp_client import MCPClient

from config import SERVER_PATH

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

TELEGRAM_BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
ALLOWED_USER_ID = int(os.environ["TELEGRAM_USER_ID"])

async def main():
    client = MCPClient()
    await client.connect_to_server(str(SERVER_PATH))
    
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    
    # Auth check
    def auth(func):
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
            if update.effective_user.id != ALLOWED_USER_ID:
                return
            return await func(update, context)
        return wrapper

    @auth
    async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
        text = update.message.text
        response = await client.process_query(text)
        await update.message.reply_text(response, parse_mode="Markdown")

    @auth
    async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE):
        file = await update.message.voice.get_file()
        audio_bytes = await file.download_as_bytearray()
        text = transcribe(("vocal.ogg", bytes(audio_bytes)))
        response = await client.process_query(text)
        await update.message.reply_text(response, parse_mode="Markdown")
    
    async def handle_clear(update, context):
        client.messages = []
        await update.message.reply_text("Contexte vidé.")

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.VOICE, handle_voice))
    app.add_handler(CommandHandler("clear", handle_clear))

    async with app:
        await app.start()
        await app.updater.start_polling()
        await asyncio.Event().wait()
        

if __name__ == "__main__":
    asyncio.run(main())