from server.mcp_instance import mcp
from enum import Enum
from config import get_db
import datetime, os, sqlite3
from config import LOGS_DIR

class Phase(str, Enum):
    PRE_ETUDE = "pre-etude"
    ARCHITECTURE = "architecture"
    DEVELOPPEMENT = "developpement"
    DOCUMENTATION = "documentation"
    ORAL = "oral"

@mcp.tool()
def create_log(text: str, phase: Phase) -> str:
    """Crée le log du jour. Utilise quand l'utilisateur raconte ce qu'il a fait, travaillé ou réfléchi. Un seul log par jour — retourne une erreur si un log existe déjà (utiliser append_to_log dans ce cas)."""
    try:
        today = datetime.date.today().isoformat()
        now = datetime.datetime.now().isoformat(timespec="seconds")
        
        try:
            con = get_db()
            db = con.cursor()
            db.execute("INSERT INTO logs (date, content, phase, char_count) VALUES (?,?,?,?)", [today, text, phase.value, len(text)])
            con.commit()
            con.close()
            
            return f"Log inséré avec succès en base de donnée pour le {today}"

        except sqlite3.IntegrityError:
            con.close()
            return f"Un log existe déjà pour le {today}. Utilise append_to_log pour ajouter du contenu."    
        
        except Exception as e:

            os.makedirs(log_dir, exist_ok=True)

            filepath = os.path.join(LOGS_DIR, f"{today}.txt")

            if os.path.exists(filepath):
                return f"Un log existe déjà pour le {today}. Utilise append_to_log pour ajouter du contenu."

            header = (
                f"date: {today}\n"
                f"phase: {phase.value}\n"
                f"created_at: {now}\n"
                f"char_count: {len(text)}\n"
                "---\n"
            )

            with open(filepath, "w") as f:
                f.write(f"{header}{text}\n")

            return f"""
                    Erreur serveur lors de l'utilisation du tool 'log_entry': {str(e)} \n
                    Fallback : Log créé pour le {today}
                    """

    except Exception as e:
        return f"Erreur serveur lors de l'utilisation du tool 'log_entry': {str(e)}, le contenu est perdu."
