import sqlite3
from config import get_db
from server.mcp_instance import mcp
from typing import List

@mcp.tool()
def get_logs(logs_list: List[str]) -> str:
    """Récupère le contenu brut des logs pour une liste de dates. Utilise pour consulter des logs existants (pas pour résumer — utiliser prepare_summary pour ça)."""
    
    if not logs_list:
        return f"Aucun logs recu, pour récupérer les logs a résumer, utilise les ressources 'list_logs_to_summarize' ou pour récupérer tout les logs 'list_logs'."

    logs_dict = {}

    try:
        con = get_db()
        db = con.cursor()

        for date in logs_list:
            row = db.execute(
                "SELECT content FROM logs WHERE date = ?", [date]
            ).fetchone()
            if row:
                logs_dict[date] = row[0]
                
        con.close()
        return str(logs_dict)
    

    except Exception as e:
        try:
            con.close()
        except:
            pass
        return f"Erreur serveur lors de l'utilisation du tool 'get_logs': {str(e)}"
