import os, sqlite3
from config import SUMMARIES_DIR
from server.mcp_instance import mcp
from config import get_db
from store.git_sync import git_sync

@mcp.tool()
def create_summary(raw_output: dict[str, str]) -> str:
    """Sauvegarde les résumés générés. Prend un dict JSON {date: contenu_markdown}. Utilise APRÈS avoir généré les résumés à partir du résultat de prepare_summary."""
    try:
        con = get_db()
        db = con.cursor()
        done = []
        
        for date, content in raw_output.items():
            done.append(f"{date}.md")
            db.execute("INSERT OR REPLACE INTO summaries (date, content) VALUES (?,?)", [date, content.strip()])
            db.execute("UPDATE logs SET summarized = 1 WHERE date = ?", [date])
            filepath = os.path.join(SUMMARIES_DIR, f"{date}.md")
            with open(filepath, "w") as f:
                f.write(content.strip())
            git_sync(date)

        con.commit()
        con.close()
        return(f"Résumés de journée crées : {', '.join(done)}:")
    except Exception as e:
        try:
            con.close()
        except:
            pass
        return f"Erreur serveur lors de l'utilisation du tool 'summarize': {str(e)}"

