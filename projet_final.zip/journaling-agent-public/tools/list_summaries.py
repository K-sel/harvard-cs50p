import sqlite3
from config import get_db
from server.mcp_instance import mcp

@mcp.tool()
def list_summaries():
    """Liste toutes les dates qui ont un résumé en base de données."""
    try:
        con = get_db()
        db = con.cursor()
        rows = db.execute("SELECT date FROM summaries").fetchall()
        con.close()
        return rows
    
    except Exception as e:
        return f"Erreur de récupération des données : {str(e)}"