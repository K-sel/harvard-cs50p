from typing import List

from server.mcp_instance import mcp
from config import get_db
from utils.prompts import summarize_day


@mcp.tool()
def prepare_summary(dates: List[str]) -> str:
    """Récupère les logs bruts pour les dates données et retourne les instructions de résumé avec les logs. Utiliser ce tool avant create_summary."""
    con = get_db()
    db = con.cursor()
    logs_dict = {}
    for date in dates:
        row = db.execute("SELECT content FROM logs WHERE date = ?", [date]).fetchone()
        if row:
            logs_dict[date] = row[0]
    con.close()

    if not logs_dict:
        return "Aucun log trouvé pour les dates demandées."

    return summarize_day() + "\n\n" + str(logs_dict)
