import sqlite3
from config import get_db
from server.mcp_instance import mcp

@mcp.tool()
def list_logs_to_summarize():
    """Liste les dates qui ont un log mais pas encore de résumé. Utilise avant prepare_summary ou quand l'utilisateur demande s'il a des résumés en retard."""
    try:
        con = get_db()
        db = con.cursor()
        rows = db.execute("SELECT date FROM logs WHERE summarized = 0").fetchall()
        con.close()
        return rows
    
    except Exception as e:
        return f"Erreur de récupération des données : {str(e)}"