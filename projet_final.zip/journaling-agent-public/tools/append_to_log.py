from server.mcp_instance import mcp
from enum import Enum
import datetime
import os
import sqlite3
from config import get_db
from config import LOGS_DIR
    
@mcp.tool()
def append_to_log(log_date: str, text: str) -> str:
    """Ajoute du contenu à un log existant. Utilise quand l'utilisateur complète une journée déjà loggée. Format date : YYYY-MM-DD."""
    try:
        datetime.date.fromisoformat(log_date)
    except ValueError:
        return "Date invalide. Le format attendu est : YYYY-MM-DD (ex: 2026-04-17)"
    
    try:
        con = get_db()
        db = con.cursor()
            
        log_exists = db.execute("SELECT id FROM logs WHERE date = ?", [log_date]).fetchone()
        
        if not log_exists:
            con.close()
            return f"Ce log n'existe pas, utilise 'tool://log_entry' pour ajouter une nouvelle entrée"
        
        db.execute("""
            UPDATE logs 
            SET content = content || ? , 
                char_count = char_count + ?, 
                modified_at = datetime('now', 'localtime') 
            WHERE date = ?
        """, [f"\n\n[EDIT {datetime.datetime.now().isoformat(timespec='seconds')}]\n{text}", len(text), log_date])    
        
        con.commit()
        con.close()
        
        return f"Log {log_date} mis à jour"
        
    except sqlite3.Error as e:
    
        try:
            filename = f"{log_date}.txt"
            filepath = os.path.join(LOGS_DIR, filename)
            
            if not os.path.exists(filepath):
                return f"Il n'y a pas de log pour la date du {log_date}, utilise le tool log_entry pour créer un log."

            with open(filepath, "a") as file:
                file.write(f"\n[EDIT {datetime.datetime.now().isoformat(timespec='seconds')}]\n{text}\n")

            update_headers(filepath)

            return f"""
                    Erreur serveur lors de l'utilisation du tool 'append_to_log': {str(e)} \n
                    Fallback : Log mis pour le {log_date}
                    """

        except Exception as e:
            return f"Erreur serveur lors de l'utilisation du tool 'append_to_log': {str(e)}"
    

def update_headers(filepath: str) -> None:
    with open(filepath, "r") as file:
        content = file.read()

    header, body = content.split("---\n", 1)
    lines = header.strip().split("\n")
    meta = {}

    for line in lines:
        key, value = line.split(": ", 1)
        meta[key] = value

    meta["modified_at"] = datetime.datetime.now().isoformat(timespec="seconds")
    meta["char_count"] = str(len(body))

    new_header = "\n".join(f"{k}: {v}" for k, v in meta.items())
    
    with open(filepath, "w") as file:
        file.write(new_header + "\n---\n" + body)