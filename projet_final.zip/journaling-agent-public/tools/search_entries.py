import faiss
from sentence_transformers import SentenceTransformer
from server.mcp_instance import mcp

index = faiss.read_index("./indexes.faiss")
k = 5 
model = SentenceTransformer("all-MiniLM-L6-v2")

@mcp.tool()
def search_entries(query: str):
    """Recherche sémantique dans les logs. Utilise quand l'utilisateur cherche un sujet spécifique dans ses logs passés. (Non implémenté)"""
    try:
        if not q:
            return f"error: pas de Query recue"

        embedding = model.encode(q)
        embedding = embedding.astype("float32")  
        embedding_2d = embedding.reshape(1, -1) 
        faiss.normalize_L2(embedding_2d) 
        distances, indices = index.search(embedding_2d, k) 

        results = []

        con = sqlite3.connect("docs.db")
        db = con.cursor()

        for i, doc_id in enumerate(indices[0]):
            id = int(doc_id)
            doc = db.execute(
                "SELECT id, title, content FROM docs WHERE id = ?", [id]
            ).fetchone()

            if doc:
                results.append(
                    {
                        "id": doc[0],
                        "title": doc[1],
                        "content": doc[2],
                        "score": float(distances[0][i]),
                    }
                )
        con.close()
        return jsonify(results)

    except Exception as e:
        return f"Erreur survenue lors de l'utilisation du tool://search_entries : {str(e)}"