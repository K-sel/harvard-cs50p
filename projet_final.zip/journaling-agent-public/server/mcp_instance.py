from mcp.server.fastmcp import FastMCP
import os

MCP_NAME = os.environ["MCP_NAME"]

mcp = FastMCP(MCP_NAME)

    
    
