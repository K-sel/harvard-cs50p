import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from server.mcp_instance import mcp
import os

import tools.create_log
import tools.append_to_log
import tools.create_summary
import tools.get_logs
import tools.list_logs_to_summarize
import tools.list_logs
import tools.list_summaries
import tools.prepare_summary

MCP_TRANSPORT = os.environ["MCP_TRANSPORT"]

def main():
    mcp.run(transport=MCP_TRANSPORT)

if __name__ == "__main__":
    main()
