from pathlib import Path
import sqlite3

# Directories
BASE_DIR = Path(__file__).parent  # racine du projet

LOGS_DIR = BASE_DIR / "store" / "logs"
SUMMARIES_DIR = BASE_DIR / "store" / "summaries"
DB_DIR = BASE_DIR / "store"
DB_NAME = "journaling_agent.db"
SERVER_PATH = BASE_DIR / "server" / "mcp_server.py"

def get_db():
    con = sqlite3.connect(DB_DIR / DB_NAME)
    db = con.cursor()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT UNIQUE NOT NULL,
            content TEXT NOT NULL,
            phase TEXT NOT NULL,
            char_count INTEGER NOT NULL,
            summarized INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
            modified_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        );
        CREATE TABLE IF NOT EXISTS summaries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT UNIQUE NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        )
    """)

    return con
