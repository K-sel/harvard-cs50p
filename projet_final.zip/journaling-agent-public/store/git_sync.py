from config import SUMMARIES_DIR
import subprocess

def git_sync(date: str) -> None:
    message = f"auto-sync:{date}.md"
    subprocess.run(["git", "add", "*.md"], cwd=SUMMARIES_DIR)
    subprocess.run(["git", "commit", "-m", message], cwd=SUMMARIES_DIR)
    subprocess.run(["git", "push", "-u", "origin", "main"], cwd=SUMMARIES_DIR)