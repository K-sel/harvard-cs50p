import datetime

def summarize_day() -> str:
    return """..."""


def get_agent_system_prompt() -> str:
    return """..."""