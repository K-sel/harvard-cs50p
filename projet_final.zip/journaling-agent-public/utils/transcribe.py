from openai import OpenAI

client = OpenAI()

def transcribe(audio_file):

    transcription = client.audio.transcriptions.create(
        model="gpt-4o-mini-transcribe", 
        file=audio_file,
        response_format="text"
    )

    return(transcription)